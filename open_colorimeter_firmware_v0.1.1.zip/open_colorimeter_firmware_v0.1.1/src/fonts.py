from adafruit_bitmap_font import bitmap_font

fontname = 'Hack-Bold'
font_14pt = bitmap_font.load_font(f'/assets/{fontname}-14.pcf')
font_10pt = bitmap_font.load_font(f'/assets/{fontname}-10.pcf')
